import torch
import torch.nn as nn
import torch.nn.functional as F
from basicsr.utils.registry import ARCH_REGISTRY
# from basicsr.archs import block as B, block  #block里面写的函数，调用的时候需要B.或者block.
from basicsr.archs import LightSR202405_block as LightSR202405_block
# from .arch_util import ResidualBlockNoBN, default_init_weights, make_layer


# @ARCH_REGISTRY.register()  #这里是注册  单独调试代码的时候可以注释这行  但是整体运行的时候记得去掉注释
class LightSR202405(nn.Module):
    #主网络
    def __init__(self,
                 num_in_ch, #输入的通道数为3。
                 num_out_ch, #输出的通道数为3。
                 num_feat, #中间特征的通道数50。
                 upscale,
                 ): #图像平均值以RGB顺序表示。
        super(LightSR202405, self).__init__()

        nf = num_feat #中间特征的通道数。

        ###############  FEB  部分  ####################
        self.IEM = LightSR202405_block.IEM(nf)  # IEM信息提取提取部分

        self.upscale = upscale
        self.fea_conv = LightSR202405_block.conv_layer(num_in_ch, nf, kernel_size=3) #输入通道为RGB3通道 输出特征为50通道中间特征通道数 3×3的卷积

        num_modules = 4  # 模块数量
        self.B1 = LightSR202405_block.FEB(in_channels=nf) #特征提取块
        self.B2 = LightSR202405_block.FEB(in_channels=nf) #特征提取块
        self.B3 = LightSR202405_block.FEB(in_channels=nf) #特征提取块
        self.B4 = LightSR202405_block.FEB(in_channels=nf) #特征提取块

        self.c = LightSR202405_block.conv_block(nf * num_modules, nf, kernel_size=1, act_type='lrelu') #激活函数
        self.LR_conv = LightSR202405_block.conv_layer(nf, nf, kernel_size=3) #Conv2d(50, 50, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        upsample_block = LightSR202405_block.pixelshuffle_block #双三次上采样模块
        self.upsampler = upsample_block(nf, num_out_ch, upscale_factor=upscale)  #上采样模块
        self.scale_idx = 0


        self.Feature_Fusion = LightSR202405_block.Feature_Fusion(channels=nf)  # 特征融合模块

    def forward(self, input):
        bi = F.interpolate(input, scale_factor=self.upscale, mode='bicubic', align_corners=False)

        _,_, h, w = input.shape
        x_size = (h, w)

        out_fea = self.fea_conv(input) #3×3的卷积     提取浅层特征

        # 分支1
        IEM = self.IEM(out_fea) # 提取细节信息


        # 分支2
        out_B1 = self.B1(out_fea, x_size) # 特征提取块

        # print('out_B1的维度', out_B1.shape)  # 向量还是矩阵

        out_B2 = self.B2(out_B1, x_size) # 特征提取块
        out_B3 = self.B3(out_B2, x_size) # 特征提取块
        out_B4 = self.B4(out_B3, x_size) # 特征提取块
        out_B = self.c(torch.cat([out_B1, out_B2, out_B3, out_B4], dim=1))  # concatenation 拼接
        out_lr = self.LR_conv(out_B) + out_fea #逐元素相加

        #  分支1和分支2两部分进行特征融合
        output = self.Feature_Fusion(out_lr, IEM)
        out_lr = output

        output = self.upsampler(out_lr) #Pixel上采样

        return output+bi #加上了增强

    def set_scale(self, scale_idx):
        self.scale_idx = scale_idx

# 模型参数计算
def count_parameters(net):
    params = list(net.parameters())
    k = 0
    for i in params:
        l = 1
        for j in i.size():
            l *= j
        k = k + l
    print("total parameters:" + str(k))


# if __name__ == '__main__':
#     x = torch.randn((16,3,64,64))
#     model = LightSR202405(num_in_ch=3, num_out_ch=3,num_feat=50,upscale=2)
#     out = model(x)
#     print(out.shape)



if __name__=='__main__':
    a=torch.rand((1,3,128,128))#.to('cuda')
    net = LightSR202405(num_in_ch=3, num_out_ch=3, num_feat=50, upscale=2)
    # net=FENet(2,num_fea=32)#.to('cuda')
    count_parameters(net)
    y=net(a)
    print(y)
    from thop import profile
    print('==> 方法1..')
    input = torch.randn(1, 3, 128//2, 128//2)
    flops, params = profile(net, (input,))
    # 打印模型的计算量（flops和参数量）
    # print('flops: %.2f M ', flops/1000000.0, 'params: %.2f K', params/1000.0)
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f M, params: %.2f K' % (flops / 1000000.0, params / 1000.0))

    #  计算模型推理时间
    import time
    t0 = time.time()
    for i in range(1):
        out = net(a)
    t = time.time() - t0
    print('平均运行时间: ', t/30)
#
#     # -- 方法2 --Mutli-adds==MACs
#     print('==> 方法2..')
#     import torchvision
#     from ptflops import get_model_complexity_info
#     x = torch.rand((1, 3, 64, 64))  # .to('cuda')
#     net2 = LightSR(num_in_ch=3, num_out_ch=3, num_feat=50, upscale=4)
#     MutliAdds, params = get_model_complexity_info(net2, (3, 224, 224), as_strings=True, print_per_layer_stat=True)
#     print('Mutli-adds: ', MutliAdds, 'params: ', params)







