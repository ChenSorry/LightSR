import torch
import torch.nn as nn
import torch.nn.functional as F
from basicsr.utils.registry import ARCH_REGISTRY
import numpy as np
from einops import rearrange
from basicsr.archs.arch_util import flow_warp
from basicsr.archs import LightSR202405_block as LightSR202405_block


@ARCH_REGISTRY.register()
class lightMamba(nn.Module):
    def __init__(self,
                 num_in_ch,
                 num_out_ch,
                 num_fea,
                 upscale,
                 ratio,
                 window_size):
        super(lightMamba, self).__init__()

        nf = num_fea
        self.conv_init = nn.Conv2d(num_in_ch, nf, kernel_size=3, padding=1, stride=1, bias=True)

        self.upscale = upscale

        self.global_predictor = nn.Sequential(
            nn.Conv2d(nf, 8, kernel_size=1, stride=1, padding=0, bias=True),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
            nn.Conv2d(2, out_channels=2, kernel_size=3, stride=1, padding=1, bias=True),
            nn.LeakyReLU(negative_slope=0.1, inplace=True)
        )
        self.b_recover = Background(dim=nf, window_size=window_size, ratio=ratio)

        self.conv_up = nn.Conv2d(nf, nf, kernel_size=3, stride=1, padding=1, bias=True)
        self.up_sample = Upsample(nf, num_out_ch, upscale_factor=upscale)

    def forward_mid(self, x, condition_global, condition_local):
        x = self.b_recover(x, condition_global, condition_local)
        return x

    def forward(self, x):
        bi = F.interpolate(x, self.upscale, mode='bicubic', align_corners=False)

        x_init = self.conv_init(int)

        condition_global = self.global_predictor(x_init)

        condition_local = self.global_predictor(condition_global)
        x_bg = self.forward_mid(x, condition_global, condition_local)





class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_first"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


def Upsample(in_channels, out_channels, upscale_factor=2, kernel_size=3, stride=1):
    conv = nn.Conv2d(in_channels, out_channels * (upscale_factor ** 2), kernel_size=3, stride=stride, padding=1, bias=True)
    pixel_shuffle = nn.PixelShuffle(upscale_factor)

    return nn.Sequential(conv, pixel_shuffle)

class PredictorLG(nn.Module):
    def __init__(self, dim, window_size=8, k=4, ratio=0.5):
        super(PredictorLG, self).__init__()

        self.ratio = ratio
        self.window_size = window_size
        cdim = dim + k
        embed_dim = window_size ** 2

        self.in_conv = nn.Sequential(
            nn.Conv2d(cdim, cdim//4, kernel_size=1, stride=1, bias=True),
            LayerNorm(cdim//4),
            nn.LeakyReLU(negative_slope=0.1, inplace=True)
        )

        self.out_offsets = nn.Sequential(
            nn.Conv2d(cdim // 4, cdim // 8, 1),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
            nn.Conv2d(cdim // 8, 2, 1),
        )

        self.out_mask = nn.Sequential(
            nn.Linear(embed_dim, window_size),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
            nn.Linear(window_size, 2),
            nn.Softmax(dim=-1)
        )

        self.out_CA = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(cdim//4, dim, kernel_size=1, stride=1, bias=True),
            nn.Sigmoid()
        )

        self.out_SA = nn.Sequential(
            nn.Conv2d(cdim//4, 1, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()
        )

    def forward(self, input_x):
        x = self.in_conv(input_x)

        offsets = self.out_offsets(x)
        offsets = offsets.tanh().mul(8.0)

        ca = self.out_CA(x)
        sa = self.out_SA(x)

        x = torch.mean(x, keepdim=True, dim=1)

        x = rearrange(x, 'b c (h dh) (w dw) -> b (h w) (dh dw c)', dh=self.window_size, dw=self.window_size)
        B, N, C = x.size()

        pre_score = self.out_mask(x)
        mask = F.gumbel_softmax(pre_score, hard=True, dim=2)[:, :, 0:1]

        return mask, offsets, ca, sa


class Background(nn.Module):
    def __init__(self, dim, window_size=8, bias=True, is_deformable=True, ratio=0.5):
        super(Background, self).__init__()

        self.dim = dim
        self.window_size = window_size
        self.is_deformable = is_deformable
        self.ratio = ratio

        k=3
        d=2

        self.conv_spatial = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=k, padding=k//2, groups=dim),
            nn.Conv2d(dim, dim, kernel_size=k, padding=((k//2)*d), groups=dim, dilation=d)
        )

        self.route = PredictorLG(dim, window_size)

    def forward(self, x, condition_global, condition_local):
        N, C, H, W = x.shape

        if self.is_deformable:
            condition_wind = torch.stack(torch.meshgrid(torch.linspace(-1, 1, self.window_size), torch.linspace(-1,1,self.window_size)))\
                    .type_as(x).unsqueeze(0).repeat(N, 1, H//self.window_size, W//self.window_size)
            if condition_global is None:
                _condition = torch.cat([condition_local, condition_wind], dim=1)
            else:
                _condition = torch.cat([condition_local, condition_global, condition_wind], dim=1)

        mask, offsets, ca, sa = self.route(_condition, ratio=self.ratio)

        xs = x * sa
        xs = rearrange(xs, 'b c (h dh) (w dw) -> b (h w) (dh dw)', dh=self.window_size, dw=self.window_size)
        x_d = xs*mask
        x_bg = xs*(1-mask)
        x_bg = self.conv_spatial(x_bg)
        out = x_d + x_bg
        out = out * ca + out

        return out



