# GENERATED VERSION FILE
# TIME: Tue Apr 12 14:13:29 2022
__version__ = '1.3.5'
__gitsha__ = 'unknown'
version_info = (1, 3, 5)
